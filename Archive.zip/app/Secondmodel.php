<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Secondmodel extends Model
{
    //
}
